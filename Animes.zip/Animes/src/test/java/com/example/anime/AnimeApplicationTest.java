package com.example.anime;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class AnimeApplicationTest {

    @Test
    void contextLoads(){}

}
