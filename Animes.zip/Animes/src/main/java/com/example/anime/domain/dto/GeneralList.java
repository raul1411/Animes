package com.example.anime.domain.dto;

import java.util.List;

public class GeneralList {

    public List<?> result;

    public GeneralList(List<?> result) {
        this.result = result;
    }
}